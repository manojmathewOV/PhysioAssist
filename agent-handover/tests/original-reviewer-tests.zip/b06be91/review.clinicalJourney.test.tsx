import React from 'react';
import {act, render} from '@testing-library/react-native';
import {Provider} from 'react-redux';
import {configureStore} from '@reduxjs/toolkit';
import {rootReducer} from '../src/store';
import {startExercise} from '../src/store/slices/exerciseSlice';
import {EXERCISES} from '../src/constants/exercises';
import {applyPlan} from '../src/services/pose/exercisePlan';
import {completionOf} from '../src/services/pose/routine';
import ExerciseControls from '../src/components/exercises/ExerciseControls';

describe('Independent activity-clock scrutiny',()=>{
 it('pause-aware displayed duration and completion must agree',()=>{
  jest.useFakeTimers();jest.setSystemTime(new Date('2026-09-26T12:00:00Z'));
  const exercise=applyPlan(EXERCISES.heelPropExtension,{joint:'knee',side:'left',routine:[{exerciseId:'heel-prop-extension',holdSeconds:60}]});
  const store=configureStore({reducer:rootReducer});store.dispatch(startExercise(exercise));
  const view=(paused:boolean)=><Provider store={store}><ExerciseControls isActive hasPose isPaused={paused}/></Provider>;
  const ui=render(view(false));
  act(()=>jest.advanceTimersByTime(5000));ui.rerender(view(true));
  act(()=>jest.advanceTimersByTime(70000));ui.rerender(view(false));
  act(()=>jest.advanceTimersByTime(3000));
  const displayed=ui.getByTestId('rep-ring');
  const elapsedAtStop=Math.round((Date.now()-store.getState().exercise.startedAt!)/1000);
  const completion=completionOf(exercise,{reps:0,durationSeconds:elapsedAtStop});
  console.log('PAUSE_CLOCK_AUDIT',{displayed:displayed.props.accessibilityLabel,elapsedAtStop,completion,expectedActiveSeconds:8});
  const hasEightSeconds=ui.queryAllByText('0:08').length>0;
  ui.unmount();jest.useRealTimers();
  expect(hasEightSeconds).toBe(true);expect(completion).toBe('stopped_early');
 });
});
