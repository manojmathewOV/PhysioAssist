/** Independent protocol-fit probes. Source is unchanged; no patients involved. */
import {todaysRoutine,nextAfter} from '../src/services/pose/routine';
import {setEpisode,confirmProgramme,setSpecialistApproved,exercisesAllowed} from '../src/services/care/episode';
import {EXERCISES} from '../src/constants/exercises';
import {PATHWAYS} from '../src/services/care/pathways';
import {measurementMethodOf} from '../src/services/movement/exerciseMovement';
const now=new Date('2026-09-27T10:01:00+10:00').getTime();
const plan:any={joint:'shoulder',side:'left',routine:[{exerciseId:'arm-raise',reps:3,timesPerDay:4}]};
const record:any={id:'one-occurrence',exerciseId:'arm-raise',joint:'left_shoulder',reps:3,completion:'completed',date:'2026-09-27T10:00:00+10:00',duration:50,formScore:0};
describe('existing confirmation and side guarantees',()=>{
 it('blocks unconfirmed programme',()=>expect(exercisesAllowed(setEpisode(plan,'frozen_shoulder'))).toBe(false));
 it('allows confirmed frozen-shoulder programme',()=>expect(exercisesAllowed(confirmProgramme(setEpisode(plan,'frozen_shoulder')))).toBe(true));
 it('requires specialist approval for generic specialist knee pathway',()=>expect(exercisesAllowed(confirmProgramme(setEpisode({joint:'knee',side:'left'},'knee_specialist')))).toBe(false));
 it('unknown-side history does not complete the prescribed side',()=>expect(todaysRoutine(plan,[{...record,joint:undefined}],now).doneCount).toBe(0));
});
describe('requirements exposed by the supplied clinic protocols',()=>{
 it('a replay of one completion must not fill a second occurrence',()=>{
  const r=todaysRoutine(plan,[record,{...record}],now);
  console.log('DUPLICATE_COMPLETION',r.doneCount,r.items.map(i=>({key:i.key,status:i.status})));
  expect(r.doneCount).toBe(1);
 });
 it('a q2-3-hour programme must not offer the next occurrence one minute later',()=>{
  const r=todaysRoutine(plan,[record],now);
  const offered=nextAfter(r,'arm-raise');
  console.log('NEXT_OCCURRENCE_AT_ONE_MINUTE',offered,r.nextIndex);
  expect(offered).toBeUndefined();
 });
});
