# Original reviewer test sources

These four files are byte-for-byte copies from earlier review bundles. They are historical evidence, not a current CI suite. The initial external-rotation-limit assumption and later plan-version grouping expectations were superseded. The b06be91 clock test reconstructs that revision's wall-time calculation. Do not use those old expectations to undo current fixes. See the repository agent-handover/tests/README.md before running. No clinical source documents, patient data, media or local paths are included.
