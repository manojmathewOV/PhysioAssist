/** Independent audit probes. Production source remains unchanged. */
import { measureStaticHold } from '../src/services/movement/staticHold';
import { MovementRecorder } from '../src/services/movement/recorder';
import { analyseSession } from '../src/services/movement/analysis';
import { sessionOutcome } from '../src/components/exercises/useMovementAnalysis';
import { exerciseValidationService as live } from '../src/services/exerciseValidationService';
import { applyPlan } from '../src/services/pose/exercisePlan';
import { EXERCISES } from '../src/constants/exercises';
import { renderBody, STANDING } from '../src/testing/virtualPatient/body';
import { mediapipeResultToPoseData } from '../src/services/pose/mediapipeLandmarks';
import { checkFraming } from '../src/components/exercises/useFramingReadiness';
import type { MovementFrame } from '../src/services/movement/types';
const f = (t:number, angle:number|null) => ({t,angle} as MovementFrame);
const plan = {joint:'knee' as const,side:'left' as const};
function pipeline(base:any, body:any, n=60, customPlan:any=plan) {
 const exercise=applyPlan(base,customPlan);
 const recorder=new MovementRecorder({joint:exercise.primaryJoint!,side:'left',exerciseId:exercise.id});
 live.startExercise(exercise);
 let validation:any;
 for(let i=0;i<n;i++) {
  const pose=mediapipeResultToPoseData(renderBody({...STANDING,...body}),{timestamp:1000+i*40})!;
  validation=live.validatePose(pose); recorder.add(pose);
 }
 const analysis=analyseSession(recorder.frames,recorder.context);
 const range=live.getSessionRange();
 const outcome=sessionOutcome(analysis,{plan:customPlan,exercise,recordingDemo:false,sessionRange:range});
 return {analysis,range,outcome,recorder,validation};
}
afterEach(()=>live.stopExercise());describe('independent patient-facing acceptance probes',()=>{
 it('positive control: continuously observed stable hold is measurable',()=>{
  const frames=Array.from({length:61},(_,i)=>f(i*40,8));
  expect(measureStaticHold(frames)?.degrees).toBeCloseTo(8);
 });
 it('must not call two observations five seconds apart a continuous hold',()=>{
  const got=measureStaticHold([f(0,8),f(5000,8)]);
  console.log('AUDIT_SPARSE_HOLD',got);
  expect(got).toBeNull();
 });
 it('must break a hold across missing-angle frames',()=>{
  const got=measureStaticHold([f(0,8),f(40,8),f(1000,null),f(5040,8),f(5080,8)]);
  console.log('AUDIT_MISSING_HOLD',got);
  expect(got).toBeNull();
 });
 it('positive control: recorder suppresses front-view squat angles',()=>{
  const p=pipeline(EXERCISES.squat,{view:'front',leftKnee:100,rightKnee:100});
  expect(p.recorder.frames.every(x=>x.angle===null)).toBe(true);
 });
 it('front-view rejection must also suppress the patient summary range',()=>{
  const p=pipeline(EXERCISES.squat,{view:'front',leftKnee:100,rightKnee:100});
  console.log('AUDIT_FRONT_SQUAT',{live:p.range,profile:p.analysis.profile,summary:p.outcome.summary.range});
  expect(p.outcome.summary.range).toBeNull();
 });
 it('heel-prop without the required stable window must have no numerical result',()=>{
  const p=pipeline(EXERCISES.heelPropExtension,{view:'lyingSide',leftKnee:175,rightKnee:175},5);
  console.log('AUDIT_SHORT_HEEL_PROP',{hold:p.analysis.hold,live:p.range,summary:p.outcome.summary.range});
  expect(p.analysis.hold).toBeNull(); expect(p.outcome.summary.range).toBeNull();
 }); it('a configured shoulder rotation limit must not be checked as arm elevation',()=>{
  const p=pipeline(EXERCISES.shoulderExternalRotation,
   {view:'front',leftForearmForward:1,leftShoulderRotation:60},60,
   {joint:'shoulder',side:'left',limitDegrees:30});
  console.log('AUDIT_ROTATION_LIMIT',{range:p.range,angle:p.recorder.frames.at(-1)?.angle,overLimit:p.validation.overLimit,feedback:p.validation.feedback,errors:p.validation.errors});
  expect(p.validation.overLimit).toBe(true);
 });
 it('shoulder setup must not report ready when both elbows and wrists are invisible',()=>{
  const pose=mediapipeResultToPoseData(renderBody({...STANDING,view:'front'}),{timestamp:1})!;
  const landmarks=pose.landmarks.map(p=>/elbow|wrist/.test(p.name??'')?{...p,visibility:0}:p);
  console.log('AUDIT_MISSING_ARMS',checkFraming(landmarks));
  expect(checkFraming(landmarks).fullBody).toBe(false);
 });
 it('proposed mode-specific setup: visible upper body should not require feet for shoulder exercise',()=>{
  const pose=mediapipeResultToPoseData(renderBody({...STANDING,view:'front'}),{timestamp:1})!;
  const landmarks=pose.landmarks.map(p=>/knee|ankle|heel|foot/.test(p.name??'')?{...p,visibility:0}:p);
  console.log('AUDIT_UPPER_BODY',checkFraming(landmarks));
  expect(checkFraming(landmarks).fullBody).toBe(true);
 });
});